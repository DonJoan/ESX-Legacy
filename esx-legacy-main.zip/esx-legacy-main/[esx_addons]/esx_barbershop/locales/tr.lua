Locales['tr'] = {
	['valid_purchase'] = 'bu işlemi doğruluyor musun?',
	['yes'] = 'evet',
	['no'] = 'hayır',
	['not_enough_money'] = 'yeterli miktarda paranız yok',
	['press_access'] = '~y~Berbere~s~ erişmek için ~INPUT_CONTEXT~ basın',
	['barber_blip'] = 'berber',
	['you_paid'] = '~g~$%s~s~ ödedin',
  }
