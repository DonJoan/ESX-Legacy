Locales['es'] = {
  ['invalid_amount'] = '~r~Cantidad no válida',
  ['deposit_money']  = 'has depositado ~g~€%s~s~',
  ['withdraw_money'] = 'has retirado ~g~€%s~s~',
  ['press_e_atm']    = 'presiona ~INPUT_PICKUP~ para depositar o retirar ~g~cash~s~.',
  ['atm_blip']       = 'ATM',
}
