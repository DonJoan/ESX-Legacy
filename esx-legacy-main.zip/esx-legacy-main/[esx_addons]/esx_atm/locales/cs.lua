Locales['cs'] = {
	['invalid_amount'] = '~r~Zadali jste neplatnou castku~s~',
	['deposit_money']  = 'vlozili jste ~g~$%s~s~',
	['withdraw_money'] = 'vybrali jste ~g~$%s~s~',
	['press_e_atm']    = 'stiskni ~INPUT_PICKUP~ pro pouziti ~g~bankomatu~s~',
	['atm_blip']       = 'bankomat',
}