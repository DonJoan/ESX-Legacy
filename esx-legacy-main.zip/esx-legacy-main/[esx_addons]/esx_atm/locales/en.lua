Locales['en'] = {
  ['invalid_amount'] = '~r~That\'s an invalid amount of money~s~',
  ['deposit_money']  = 'you have deposited ~g~$%s~s~',
  ['withdraw_money'] = 'you have withdrawn ~g~$%s~s~',
  ['press_e_atm']    = 'press ~INPUT_PICKUP~ for deposit or withdrawal from ~g~ATM~s~',
  ['atm_blip']       = 'ATM',
}
