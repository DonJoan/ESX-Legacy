USE `es_extended`;

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Bröd', 1),
	('water', 'Vatten', 1)
;
