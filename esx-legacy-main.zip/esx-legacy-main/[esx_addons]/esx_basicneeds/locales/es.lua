Locales['es'] = {
  ['used_bread'] = 'Has usado ~y~1x~s~ ~b~pan~s~',
  ['used_water'] = 'Has usado ~y~1x~s~ ~b~agua~s~',
}