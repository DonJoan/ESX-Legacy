Locales['es'] = {
	['veh_released'] = 'has sacado tu vehículo',
	['veh_stored'] = 'has guardado tu vehículo',
	['veh_health'] = 'debes de reparar tu vehículo antes de guardarlo',
}
