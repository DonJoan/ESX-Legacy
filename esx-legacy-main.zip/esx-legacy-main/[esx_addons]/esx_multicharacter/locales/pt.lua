Locales['pt'] = {
	['male'] = "Masculino",
	['female'] = "Feminino",
	['delete_label'] = "Eliminar %s %s?",
	['select_char'] = "Selecionar personagem",
	['create_char'] = "Criar novo personagem",
	['char_play'] = "Selecionar",
	['char_delete'] = "Eliminar personagem",
	['cancel'] = "Cancelar",
	['confirm'] = "Confirmar",
}
