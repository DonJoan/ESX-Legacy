Locales['tr'] = {
  ['skin_menu'] = 'Karakter Menüsü',
  ['use_rotate_view'] = '~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ ve ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ ile kamera açısını değiştirebilirsiniz.',
  ['skin'] = 'Karakter Değiştir',
  ['saveskin'] = 'Karakteri bir dosyaya kaydet',
}